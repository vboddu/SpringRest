package fileupload.storage;

import java.nio.file.Path;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

/**
 * Interface that defines methods for File storage operations
 *
 */
public interface FileStorageService {

    void store(MultipartFile file);

    Resource loadAsResource(String filename);

    Path load(String filename);
    
}
