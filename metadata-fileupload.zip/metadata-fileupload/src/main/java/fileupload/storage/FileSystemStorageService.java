package fileupload.storage;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

/**
 * Contains methods to store and retrieve uploaded files  
 *
 */
@Service
public class FileSystemStorageService implements FileStorageService {

    private final Path rootLocation;

    /**
     * Constructor creates directory if not already exists at start up
     * @param properties
     */
    @Autowired
    public FileSystemStorageService(StorageProperties properties) {
    	
        this.rootLocation = Paths.get(properties.getLocation());
        
        try {
            Files.createDirectory(rootLocation);
        } catch(FileAlreadyExistsException e){
        	// ignore, as directory was already created 
        	
        } catch (IOException e) {
            throw new StorageException("Could not initialize storage", e);
        }	
    }
    
    /**
     * Method to store the uploaded
     */
    @Override
    public void store(MultipartFile file) {
        try {
            if (file.isEmpty()) {
                throw new StorageException("Failed to store empty file " + file.getOriginalFilename());
            }
            Files.copy(file.getInputStream(), this.rootLocation.resolve(file.getOriginalFilename()));
        } catch (IOException e) {
            throw new StorageException("Failed to store file " + file.getOriginalFilename(), e);
        }
    }
    
    /**
     * Loads the file as resource
     * Throws an exception if file is not found
     */
    @Override
    public Resource loadAsResource(String filename) {
        try {
            Path file = load(filename);
            Resource resource = new UrlResource(file.toUri());
            if(resource.exists() || resource.isReadable()) {
                return resource;
            }
            else {
                throw new StorageFileNotFoundException("Could not read file: " + filename);

            }
        } catch (MalformedURLException e) {
            throw new StorageFileNotFoundException("Could not read file: " + filename, e);
        }
    }

    @Override
    public Path load(String filename) {
        return rootLocation.resolve(filename);
    }

}
