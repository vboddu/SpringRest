package fileupload.ehcache;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Contain cache properties
 * 
 * @author venkatavamseeboddu
 *
 */
@ConfigurationProperties("cache")
public class CacheProperties {

    /**
     * Folder location for storing files
     */
	@Value( "${ehcache.config:ehcache.xml}" )
    private String location;

	@Value( "${ehcache.name:metadataCache}" )
	private String cacheName;

    public String getCacheName() {
		return cacheName;
	}

	public void setCacheName(String cacheName) {
		this.cacheName = cacheName;
	}

	public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

}
