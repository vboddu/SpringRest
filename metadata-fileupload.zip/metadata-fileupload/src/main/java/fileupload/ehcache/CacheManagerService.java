package fileupload.ehcache;

import net.sf.ehcache.Ehcache;

/**
 * Cache manager interface
 * 
 */
public interface CacheManagerService {

	public Ehcache getCache();
	
}
