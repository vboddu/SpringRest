package fileupload.ehcache;

import java.io.IOException;
import java.io.InputStream;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * This class creates, returns and manages the caches in EhCache. */

@Service
public class EhCacheManagerService implements CacheManagerService{
	
	private Ehcache ehcache;

	public Ehcache getCache(){
		return ehcache;
	}
	
	@Autowired
    public EhCacheManagerService(CacheProperties properties) throws Exception {
        
    	String cacheConfigFile = properties.getLocation();
    	String cacheName = properties.getCacheName();
    	
    	try(InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(cacheConfigFile))
		{
			if(inputStream == null) {
				
				System.out.println("File: "+cacheConfigFile+" not available on File System...");
			}
				
			CacheManager cacheManager = CacheManager.create(inputStream);
			System.out.println("Cache initialized with : "+cacheConfigFile);
			
			ehcache = cacheManager.getEhcache(cacheName);
			
			if(ehcache == null){
				throw new Exception("Cache : "+cacheName+" is not found");
			}
			
		}catch(IOException e){
			e.printStackTrace();
		}
    	
    }
	
}