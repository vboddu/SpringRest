package fileupload.metadata;

import java.util.List;
import java.util.Map;

/**
 * Interface that specifies the methods for Metadata operations  
 *
 */
public interface MetadataStorageService {

	void addMetadata(Map<String, String> map);
	
	Map<String, String> getFileDetails(String fileId);
	
	public List<Map<String, String>> getAllFilesDetails();
	
	public List<String> listFileIDs(String match);
}
