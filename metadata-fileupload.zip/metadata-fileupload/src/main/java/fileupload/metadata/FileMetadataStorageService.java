package fileupload.metadata;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fileupload.ehcache.CacheManagerService;
import fileupload.storage.StorageFileNotFoundException;

/**
 * This class creates, returns and manages the caches in EhCache. */

@Service
public class FileMetadataStorageService implements MetadataStorageService{

	private CacheManagerService cacheManager;

	@Autowired
	public FileMetadataStorageService(CacheManagerService cacheManager){
	
		this.cacheManager = cacheManager;
	}
	
	/**
	 * Method adds file metadata (key, value) pair to Cache 
	 */
	@Override
	public void addMetadata(Map<String, String> map) {

		cacheManager.getCache().put(new Element(map.get("id"), map));
//		System.out.println("File Details added successfully");
	}
	
	/**
	 * Get file details by File ID
	 */
	@Override
	public Map<String, String> getFileDetails(String fileId){

		Element element = cacheManager.getCache().get(fileId);
		
		if (element == null){
			throw new FileMetadataNotFoundException("File with Id: " + fileId + " not found");
		}
		Map<String, String> map = (Map<String, String>)element.getObjectValue();
//		System.out.println("File Details fetched successfully");
		return map;
	}
	
	/**
	 * Get metadata of all file available in Storage
	 */
	@Override
	public List<Map<String, String>> getAllFilesDetails(){

		List<Map<String, String>> list = new ArrayList<>();
		Ehcache cache = cacheManager.getCache();
		List<String> keys = cache.getKeys();
		Element e;
		for(String key : keys){
			
			e = cache.get(key);
			list.add((Map<String, String>) e.getObjectValue());
		}
		if(list.size() == 0){
			
				throw new FileMetadataNotFoundException("No File data found");
		}
		return list;
	}

	/**
	 * Get the list of File IDs that matches with the given string 
	 */
	@Override
	public List<String> listFileIDs(String match) {

		List<String> list = new ArrayList<>();
		Ehcache cache = cacheManager.getCache();
		List<String> keys = cache.getKeys();
		Element e;
		for(String key : keys){
			
			if(key.contains(match)){
				
				list.add((String)key);
			}
			
		}
		if(list.size() == 0){
			
			throw new FileMetadataNotFoundException("No File ID matches with "+ match);
		}
		return list;
	}
}