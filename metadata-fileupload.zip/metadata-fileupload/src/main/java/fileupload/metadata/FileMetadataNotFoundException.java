package fileupload.metadata;

import fileupload.storage.StorageException;

/**
 * Exception class for metadata not found 
 */
public class FileMetadataNotFoundException extends StorageException {

    public FileMetadataNotFoundException(String message) {
        super(message);
    }

    public FileMetadataNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}