package fileupload;

import fileupload.metadata.FileMetadataNotFoundException;
import fileupload.metadata.MetadataStorageService;
import fileupload.storage.FileStorageService;
import fileupload.storage.StorageFileNotFoundException;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * This class acts as controller component.
 * Being Rest controller, its by default Response Body and objects are treated as JSON
 * Contains method mapping for invoked Rest web service endpoints
 */
@RestController
public class FileUploadController {

    private final FileStorageService fileStorageService;
    private final MetadataStorageService metadataStorageService;

    @Autowired
    public FileUploadController( FileStorageService fileStorageService ,  MetadataStorageService metadataStorageService) {
        this.fileStorageService = fileStorageService;
        this.metadataStorageService = metadataStorageService;
    }

    /**
     * To upload the file and metadata details
     * @param file
     * @param map
     * @return
     */
    @PostMapping("/upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file, @RequestParam Map<String, String> map) {

        fileStorageService.store(file);
        metadataStorageService.addMetadata(map);
        
        return "You successfully uploaded " + file.getOriginalFilename();
    }

    /**
     * Handles exception when storage file is not found
     * @param exc
     * @return
     */
    @ExceptionHandler(StorageFileNotFoundException.class)
    public ResponseEntity handleStorageFileNotFound(StorageFileNotFoundException exc) {
        return ResponseEntity.notFound().build();
    }
    
    /**
     * Handles exception when file metadata is not found
     * @param exc
     * @return
     */
    @ExceptionHandler(FileMetadataNotFoundException.class)
    public ResponseEntity handleFileNotFound(FileMetadataNotFoundException exc) {
        return ResponseEntity.notFound().build();
    }
    
    /**
     * Get metadata of a file identified by File ID
     * @param fileId
     * @return
     */
	  @GetMapping("/list/{fileId}")
	  public Map<String, String> getFileDetails(@PathVariable String fileId) {
	
		 return metadataStorageService.getFileDetails(fileId);
	  }
	    
	  /**
	   * Get the list of all files' metadata
	   * @return
	   */
	  @GetMapping("/list")
	  public List<Map<String, String>> getAllFilesDetails() {
	
		  return metadataStorageService.getAllFilesDetails();
	  }
    
	  /**
	   * Get the file content by file name
	   * @param filename
	   * @return
	   */
    @GetMapping("/files/{filename:.+}")
    public ResponseEntity<Resource> getFileContent(@PathVariable String filename) {

        Resource fileResource = fileStorageService.loadAsResource(filename);
        return ResponseEntity
                .ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\""+fileResource.getFilename()+"\"")
                .body(fileResource);
    }

    /**
     * List all the file IDs that contains the argument
     * @param match
     * @return
     */
    @GetMapping("/fileIDs/{match}")
    public List<String> getFileIDs(@PathVariable String match) {

        return metadataStorageService.listFileIDs(match);
    }
}
