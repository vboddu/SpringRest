package fileupload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import fileupload.ehcache.CacheProperties;
import fileupload.storage.StorageProperties;

/**
 * This class is to launch the Spring Boot application
 */
@SpringBootApplication
@EnableConfigurationProperties({StorageProperties.class, CacheProperties.class})
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

}
